//
//  AppDelegate.h
//  collectionview
//
//  Created by Dinesh Jaganathan on 25/09/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

