//
//  ViewController.m
//  collectionview
//
//  Created by Dinesh Jaganathan on 25/09/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import "ViewController.h"
#import "collectionview.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section;
{
    return 6;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath;
{
    collectionview *cell =[collectionView dequeueReusableCellWithReuseIdentifier:@"f1" forIndexPath:indexPath];
    cell.i1.image=[UIImage imageNamed:@"11.jpg"];
    return cell;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
